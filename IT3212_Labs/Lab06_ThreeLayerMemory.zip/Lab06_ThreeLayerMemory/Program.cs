﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.GUI; // Thêm dòng này

namespace Lab06_ThreeLayerMemory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Application.Run(new frmQuanLySinhVien());
        }
    }
}