﻿using System;

namespace Lab06_ThreeLayerMemory
{
    public class SanPham
    {
        public string MaSP { get; set; }
        public string TenSP { get; set; }
        public int SoLuong { get; set; }
        public double DonGia { get; set; }
        public double ThanhTien => SoLuong * DonGia;

        public SanPham() { }

        public SanPham(string maSP, string tenSP, int soLuong, double donGia)
        {
            MaSP = maSP;
            TenSP = tenSP;
            SoLuong = soLuong;
            DonGia = donGia;
        }
    }
}