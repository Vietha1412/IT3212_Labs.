﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;

namespace Lab06_ThreeLayerMemory.GUI
{
    public partial class frmListViewIcon : Form
    {
        private readonly SinhVienBUS _bus = new SinhVienBUS();

        public frmListViewIcon()
        {
            InitializeComponent();
        }

        private void frmListViewIcon_Load(object sender, EventArgs e)
        {
            // Thiết lập liên kết ImageList với ListView
            lvSinhVien.LargeImageList = imgListLarge;
            lvSinhVien.SmallImageList = imgListSmall;
            lvSinhVien.View = View.Details;
            lvSinhVien.FullRowSelect = true;
            lvSinhVien.GridLines = true;

            // Khởi tạo các cột cho ListView nếu chưa có
            if (lvSinhVien.Columns.Count == 0)
            {
                lvSinhVien.Columns.Add("Mã SV", 90);
                lvSinhVien.Columns.Add("Họ và Tên", 150);
                lvSinhVien.Columns.Add("Điểm TB", 80);
                lvSinhVien.Columns.Add("Xếp loại", 100);
            }

            LoadDataToListView();
        }

        private void LoadDataToListView()
        {
            lvSinhVien.Items.Clear();
            var listSinhVien = _bus.GetAll();

            foreach (var sv in listSinhVien)
            {
                ListViewItem item = new ListViewItem(sv.MaSV);
                item.SubItems.Add(sv.HoTen);
                item.SubItems.Add(sv.DiemTB.ToString("N2"));

                // Xác định biểu tượng (ImageIndex) và trạng thái dựa trên điểm trung bình
                int imageIndex = 2; // Mặc định vị trí icon cho Trung bình (Index 2)
                string xepLoai = "Trung bình";

                if (sv.DiemTB >= 8.0)
                {
                    imageIndex = 0; // Vị trí icon cho loại Giỏi trong ImageList
                    xepLoai = "Giỏi";
                }
                else if (sv.DiemTB >= 6.5)
                {
                    imageIndex = 1; // Vị trí icon cho loại Khá trong ImageList
                    xepLoai = "Khá";
                }

                item.SubItems.Add(xepLoai);
                item.ImageIndex = imageIndex; // Gắn chỉ số icon tương ứng vào dòng của ListView
                lvSinhVien.Items.Add(item);
            }
        }
    }
}