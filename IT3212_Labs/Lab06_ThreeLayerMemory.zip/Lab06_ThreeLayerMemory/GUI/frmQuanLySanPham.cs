﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;

namespace Lab06_ThreeLayerMemory
{
    public partial class frmQuanLySanPham : Form
    {
        private readonly SanPhamBUS _bus = new SanPhamBUS();
        private BindingList<SanPham> _dsSanPham;

        public frmQuanLySanPham()
        {
            InitializeComponent();
        }

        private void frmQuanLySanPham_Load(object sender, EventArgs e)
        {
            LoadData(_bus.GetAll());
        }

        private void LoadData(List<SanPham> list)
        {
            _dsSanPham = new BindingList<SanPham>(list);
            dgvSanPham.DataSource = _dsSanPham;
            dgvSanPham.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            UpdateTotalInventory();
        }

        private void UpdateTotalInventory()
        {
            double total = _bus.CalculateTotalInventoryValue();
            lblTongGiaTri.Text = $"Tổng giá trị hàng tồn: {total:N2} VNĐ";
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtSoLuong.Text.Trim(), out int sl) || sl < 0)
                {
                    MessageBox.Show("Số lượng phải là số nguyên hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (!double.TryParse(txtDonGia.Text.Trim(), out double dg) || dg < 0)
                {
                    MessageBox.Show("Đơn giá phải là số hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                SanPham sp = new SanPham(txtMaSP.Text.Trim(), txtTenSP.Text.Trim(), sl, dg);
                _bus.Add(sp);
                LoadData(_bus.GetAll());
                MessageBox.Show("Thêm sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi nghiệp vụ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSanPham.CurrentRow == null || !(dgvSanPham.CurrentRow.DataBoundItem is SanPham sp))
                {
                    MessageBox.Show("Vui lòng chọn sản phẩm cần sửa trên bảng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(txtSoLuong.Text.Trim(), out int sl) || sl < 0)
                {
                    MessageBox.Show("Số lượng phải là số nguyên hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (!double.TryParse(txtDonGia.Text.Trim(), out double dg) || dg < 0)
                {
                    MessageBox.Show("Đơn giá phải là số hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                sp.TenSP = txtTenSP.Text.Trim();
                sp.SoLuong = sl;
                sp.DonGia = dg;

                _bus.Update(sp);
                LoadData(_bus.GetAll());
                MessageBox.Show("Cập nhật sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi nghiệp vụ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvSanPham.CurrentRow == null || !(dgvSanPham.CurrentRow.DataBoundItem is SanPham sp))
                {
                    MessageBox.Show("Vui lòng chọn sản phẩm cần xóa trên bảng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _bus.Delete(sp.MaSP);
                LoadData(_bus.GetAll());
                MessageBox.Show("Xóa sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            string keyword = txtTimKiem.Text.Trim();
            var result = _bus.Search(keyword);
            LoadData(result);
        }

        private void btnSapXep_Click(object sender, EventArgs e)
        {
            var result = _bus.SortByPriceAscending();
            LoadData(result);
        }

        private void dgvSanPham_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvSanPham.CurrentRow != null && dgvSanPham.CurrentRow.DataBoundItem is SanPham sp)
            {
                txtMaSP.Text = sp.MaSP;
                txtTenSP.Text = sp.TenSP;
                txtSoLuong.Text = sp.SoLuong.ToString();
                txtDonGia.Text = sp.DonGia.ToString();
            }
        }
    }
}