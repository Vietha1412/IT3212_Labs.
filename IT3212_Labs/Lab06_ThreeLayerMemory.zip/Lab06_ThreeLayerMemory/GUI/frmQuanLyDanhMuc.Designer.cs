﻿namespace Lab06_ThreeLayerMemory.GUI
{
    partial class frmQuanLyDanhMuc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tvDanhMuc = new System.Windows.Forms.TreeView();
            this.cmsDanhMuc = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dANHMỤCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDoiTen = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuXoa = new System.Windows.Forms.ToolStripMenuItem();
            this.cmsDanhMuc.SuspendLayout();
            this.SuspendLayout();
            // 
            // tvDanhMuc
            // 
            this.tvDanhMuc.Location = new System.Drawing.Point(110, 99);
            this.tvDanhMuc.Name = "tvDanhMuc";
            this.tvDanhMuc.Size = new System.Drawing.Size(945, 158);
            this.tvDanhMuc.TabIndex = 0;
            this.tvDanhMuc.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvDanhMuc_AfterLabelEdit);
            this.tvDanhMuc.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvDanhMuc_AfterSelect);
            // 
            // cmsDanhMuc
            // 
            this.cmsDanhMuc.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsDanhMuc.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dANHMỤCToolStripMenuItem});
            this.cmsDanhMuc.Name = "cmsDanhMuc";
            this.cmsDanhMuc.Size = new System.Drawing.Size(158, 28);
            // 
            // dANHMỤCToolStripMenuItem
            // 
            this.dANHMỤCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuThem});
            this.dANHMỤCToolStripMenuItem.Name = "dANHMỤCToolStripMenuItem";
            this.dANHMỤCToolStripMenuItem.Size = new System.Drawing.Size(157, 24);
            this.dANHMỤCToolStripMenuItem.Text = "DANH MỤC";
            // 
            // mnuThem
            // 
            this.mnuThem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuDoiTen});
            this.mnuThem.Name = "mnuThem";
            this.mnuThem.Size = new System.Drawing.Size(224, 26);
            this.mnuThem.Text = "Thêm";
            this.mnuThem.Click += new System.EventHandler(this.mnuThem_Click);
            // 
            // mnuDoiTen
            // 
            this.mnuDoiTen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuXoa});
            this.mnuDoiTen.Name = "mnuDoiTen";
            this.mnuDoiTen.Size = new System.Drawing.Size(224, 26);
            this.mnuDoiTen.Text = "Đổi tên";
            this.mnuDoiTen.Click += new System.EventHandler(this.mnuDoiTen_Click);
            // 
            // mnuXoa
            // 
            this.mnuXoa.Name = "mnuXoa";
            this.mnuXoa.Size = new System.Drawing.Size(224, 26);
            this.mnuXoa.Text = "Xóa";
            this.mnuXoa.Click += new System.EventHandler(this.mnuXoa_Click);
            // 
            // frmQuanLyDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1172, 450);
            this.Controls.Add(this.tvDanhMuc);
            this.Name = "frmQuanLyDanhMuc";
            this.Text = "frmQuanLyDanhMuc";
            this.Load += new System.EventHandler(this.frmQuanLyDanhMuc_Load);
            this.cmsDanhMuc.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tvDanhMuc;
        private System.Windows.Forms.ContextMenuStrip cmsDanhMuc;
        private System.Windows.Forms.ToolStripMenuItem dANHMỤCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuThem;
        private System.Windows.Forms.ToolStripMenuItem mnuDoiTen;
        private System.Windows.Forms.ToolStripMenuItem mnuXoa;
    }
}