﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;

namespace Lab06_ThreeLayerMemory.GUI
{
    public partial class frmQuanLyDanhMuc : Form
    {
        private readonly DanhMucBUS _bus = new DanhMucBUS();

        public frmQuanLyDanhMuc()
        {
            InitializeComponent();
        }

        private void frmQuanLyDanhMuc_Load(object sender, EventArgs e)
        {
            tvDanhMuc.LabelEdit = true;
            LoadDataToTree();
        }

        private void LoadDataToTree()
        {
            tvDanhMuc.Nodes.Clear();
            var data = _bus.GetAll();

            foreach (var group in data)
            {
                TreeNode catNode = new TreeNode(group.Key);
                foreach (var item in group.Value)
                {
                    catNode.Nodes.Add(new TreeNode(item));
                }
                tvDanhMuc.Nodes.Add(catNode);
            }
            tvDanhMuc.ExpandAll();
        }

        // Đồng bộ ngược từ TreeView xuống tầng BUS/DAL khi có thay đổi cấu trúc cây
        private void SyncTreeToDatabase()
        {
            Dictionary<string, List<string>> newData = new Dictionary<string, List<string>>();

            foreach (TreeNode rootNode in tvDanhMuc.Nodes)
            {
                List<string> childList = new List<string>();
                foreach (TreeNode childNode in rootNode.Nodes)
                {
                    childList.Add(childNode.Text);
                }
                newData[rootNode.Text] = childList;
            }

            _bus.SaveData(newData);
        }

        private void mnuThem_Click(object sender, EventArgs e)
        {
            TreeNode newNode = new TreeNode("Mục mới");
            if (tvDanhMuc.SelectedNode != null)
            {
                tvDanhMuc.SelectedNode.Nodes.Add(newNode);
                tvDanhMuc.SelectedNode.Expand();
            }
            else
            {
                tvDanhMuc.Nodes.Add(newNode);
            }
            tvDanhMuc.SelectedNode = newNode;
            newNode.BeginEdit();
            SyncTreeToDatabase();
        }

        private void mnuDoiTen_Click(object sender, EventArgs e)
        {
            if (tvDanhMuc.SelectedNode != null)
            {
                tvDanhMuc.SelectedNode.BeginEdit();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn mục cần đổi tên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void tvDanhMuc_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            if (e.Label != null)
            {
                if (string.IsNullOrWhiteSpace(e.Label))
                {
                    MessageBox.Show("Tên mục không được để trống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.CancelEdit = true;
                }
                else
                {
                    // Cập nhật lại dữ liệu sau khi sửa nhãn thành công
                    BeginInvoke((MethodInvoker)SyncTreeToDatabase);
                }
            }
        }

        private void mnuXoa_Click(object sender, EventArgs e)
        {
            if (tvDanhMuc.SelectedNode != null)
            {
                DialogResult dr = MessageBox.Show($"Bạn có chắc chắn muốn xóa mục '{tvDanhMuc.SelectedNode.Text}' không?",
                    "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    tvDanhMuc.SelectedNode.Remove();
                    SyncTreeToDatabase();
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn mục cần xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void tvDanhMuc_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}