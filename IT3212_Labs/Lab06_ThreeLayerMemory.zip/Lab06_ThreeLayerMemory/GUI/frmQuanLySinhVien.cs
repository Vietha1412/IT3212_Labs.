﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using Lab06_ThreeLayerMemory.BUS;

namespace Lab06_ThreeLayerMemory
{
    public partial class frmQuanLySinhVien : Form
    {
        private readonly SinhVienBUS _bus = new SinhVienBUS();
        private BindingList<SinhVien> _dsSinhVien;

        public frmQuanLySinhVien()
        {
            InitializeComponent();
        }

        private void frmQuanLySinhVien_Load(object sender, EventArgs e)
        {
            LoadDataToDataGridView();
            LoadDataToListView();
            LoadDataToTreeView();
        }

        private void LoadDataToDataGridView()
        {
            var list = _bus.GetAll();
            _dsSinhVien = new BindingList<SinhVien>(list);
            dgvSinhVien.AutoGenerateColumns = true;
            dgvSinhVien.DataSource = _dsSinhVien;
            dgvSinhVien.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void LoadDataToListView()
        {
            lvSinhVien.Items.Clear();
            lvSinhVien.View = View.Details;
            lvSinhVien.FullRowSelect = true;
            lvSinhVien.GridLines = true;

            // Thiết lập các cột cho ListView nếu chưa có
            if (lvSinhVien.Columns.Count == 0)
            {
                lvSinhVien.Columns.Add("Mã SV", 90);
                lvSinhVien.Columns.Add("Họ và Tên", 150);
                lvSinhVien.Columns.Add("Điểm TB", 80);
            }

            foreach (var sv in _bus.GetAll())
            {
                ListViewItem item = new ListViewItem(sv.MaSV);
                item.SubItems.Add(sv.HoTen);
                item.SubItems.Add(sv.DiemTB.ToString("N2"));
                item.Tag = sv;
                lvSinhVien.Items.Add(item);
            }
        }

        private void LoadDataToTreeView()
        {
            tvKhoa.Nodes.Clear();
            var groupedData = _bus.GetGroupedByKhoa();

            foreach (var group in groupedData)
            {
                TreeNode khoaNode = new TreeNode(group.Key);
                foreach (var sv in group.Value)
                {
                    TreeNode svNode = new TreeNode($"{sv.MaSV} - {sv.HoTen}");
                    svNode.Tag = sv;
                    khoaNode.Nodes.Add(svNode);
                }
                tvKhoa.Nodes.Add(khoaNode);
            }
            tvKhoa.ExpandAll();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                if (!double.TryParse(txtDiemTB.Text.Trim(), out double diem))
                {
                    MessageBox.Show("Điểm trung bình phải là số hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                SinhVien svMoi = new SinhVien(
                    txtMaSV.Text.Trim(),
                    txtHoTen.Text.Trim(),
                    DateTime.Today,
                    diem,
                    string.IsNullOrWhiteSpace(txtKhoa.Text) ? "Khác" : txtKhoa.Text.Trim()
                );

                _bus.Add(svMoi);

                // Làm mới hiển thị trên tất cả các Control
                LoadDataToDataGridView();
                LoadDataToListView();
                LoadDataToTreeView();

                MessageBox.Show("Thêm sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi nghiệp vụ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string maSV = string.Empty;

                if (dgvSinhVien.CurrentRow != null && dgvSinhVien.CurrentRow.DataBoundItem is SinhVien sv)
                {
                    maSV = sv.MaSV;
                }

                if (string.IsNullOrEmpty(maSV))
                {
                    MessageBox.Show("Vui lòng chọn dòng sinh viên trên DataGridView để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _bus.Delete(maSV);

                // Làm mới hiển thị
                LoadDataToDataGridView();
                LoadDataToListView();
                LoadDataToTreeView();

                MessageBox.Show("Xóa sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvSinhVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnLuuFile_Click(object sender, EventArgs e)
        {
            try
            {
                _bus.ExportToCsv();
                MessageBox.Show("Đã xuất danh sách sinh viên ra tệp DanhSachSinhVien.csv thành công!",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}