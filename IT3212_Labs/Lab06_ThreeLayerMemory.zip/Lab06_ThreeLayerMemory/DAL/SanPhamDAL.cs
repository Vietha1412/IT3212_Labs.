﻿using System.Collections.Generic;
using System.Linq;

namespace Lab06_ThreeLayerMemory.DAL
{
    public class SanPhamDAL
    {
        private readonly List<SanPham> _data = new List<SanPham>
        {
            new SanPham("SP01", "Bút bi", 100, 5000),
            new SanPham("SP02", "Vở học sinh", 200, 10000),
            new SanPham("SP03", "Thước kẻ", 50, 4000)
        };

        public List<SanPham> GetAll() => new List<SanPham>(_data);

        public void Add(SanPham sp) => _data.Add(sp);

        public void Update(SanPham sp)
        {
            var existing = _data.FirstOrDefault(x => x.MaSP == sp.MaSP);
            if (existing != null)
            {
                existing.TenSP = sp.TenSP;
                existing.SoLuong = sp.SoLuong;
                existing.DonGia = sp.DonGia;
            }
        }

        public void Delete(string maSP)
        {
            var sp = _data.FirstOrDefault(x => x.MaSP == maSP);
            if (sp != null) _data.Remove(sp);
        }


    }
}