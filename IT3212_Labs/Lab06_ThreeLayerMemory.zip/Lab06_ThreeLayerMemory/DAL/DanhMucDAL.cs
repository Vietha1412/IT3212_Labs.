﻿using System.Collections.Generic;

namespace Lab06_ThreeLayerMemory.DAL
{
    public class DanhMucDAL
    {
        private readonly Dictionary<string, List<string>> _data = new Dictionary<string, List<string>>()
        {
            { "Điện tử", new List<string> { "Laptop Gaming", "Điện thoại thông minh" } },
            { "Đồ gia dụng", new List<string> { "Nồi cơm điện tử", "Máy lọc nước" } }
        };

        public Dictionary<string, List<string>> GetAll() => _data;

        public void SaveChanges(Dictionary<string, List<string>> newData)
        {
            _data.Clear();
            foreach (var pair in newData)
            {
                _data[pair.Key] = new List<string>(pair.Value);
            }
        }
    }
}