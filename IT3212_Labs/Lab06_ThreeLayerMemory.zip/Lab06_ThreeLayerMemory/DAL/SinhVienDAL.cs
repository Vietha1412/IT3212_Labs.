﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Lab06_ThreeLayerMemory.DAL
{
    public class SinhVienDAL
    {
        private readonly List<SinhVien> _data = new List<SinhVien>();
        private readonly string _filePath = "DanhSachSinhVien.csv";

        public SinhVienDAL()
        {
            // Tự động đọc dữ liệu từ tệp CSV khi khởi tạo DAL
            LoadFromCsv();
        }

        public List<SinhVien> GetAll() => new List<SinhVien>(_data);

        public void Add(SinhVien sv)
        {
            _data.Add(sv);
            SaveToCsv(); // Tự động ghi lại tệp CSV sau khi thêm
        }

        public void Delete(string maSV)
        {
            var sv = _data.FirstOrDefault(x => x.MaSV == maSV);
            if (sv != null)
            {
                _data.Remove(sv);
                SaveToCsv(); // Tự động cập nhật lại tệp CSV sau khi xóa
            }
        }

        // Phương thức lưu dữ liệu ra tệp CSV
        public void SaveToCsv()
        {
            try
            {
                List<string> lines = new List<string>();
                // Ghi tiêu đề cột
                lines.Add("MaSV,HoTen,NgaySinh,DiemTB,Khoa");

                foreach (var sv in _data)
                {
                    string line = $"{sv.MaSV},{sv.HoTen},{sv.NgaySinh:yyyy-MM-dd},{sv.DiemTB},{sv.Khoa}";
                    lines.Add(line);
                }

                File.WriteAllLines(_filePath, lines, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi ghi tệp CSV: " + ex.Message);
            }
        }

        // Phương thức đọc dữ liệu từ tệp CSV
        public void LoadFromCsv()
        {
            _data.Clear();

            if (!File.Exists(_filePath))
            {
                // Nếu tệp chưa tồn tại, khởi tạo danh sách mẫu mặc định
                _data.Add(new SinhVien("SV01", "Nguyễn An", new DateTime(2004, 5, 15), 8.2, "Công nghệ Thông tin"));
                _data.Add(new SinhVien("SV02", "Trần Bình", new DateTime(2004, 8, 20), 7.0, "Công nghệ Thông tin"));
                _data.Add(new SinhVien("SV03", "Lê Chi", new DateTime(2005, 1, 10), 9.1, "Quản trị Kinh doanh"));
                SaveToCsv(); // Ghi tạo tệp ban đầu
                return;
            }

            try
            {
                string[] lines = File.ReadAllLines(_filePath, Encoding.UTF8);

                // Bỏ qua dòng tiêu đề đầu tiên (index = 0)
                for (int i = 1; i < lines.Length; i++)
                {
                    if (string.IsNullOrWhiteSpace(lines[i])) continue;

                    string[] parts = lines[i].Split(',');
                    if (parts.Length >= 5)
                    {
                        string maSV = parts[0].Trim();
                        string hoTen = parts[1].Trim();
                        DateTime ngaySinh = DateTime.Parse(parts[2].Trim());
                        double diemTB = double.Parse(parts[3].Trim());
                        string khoa = parts[4].Trim();

                        _data.Add(new SinhVien(maSV, hoTen, ngaySinh, diemTB, khoa));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi khi đọc tệp CSV: " + ex.Message);
            }
        }
    }
}