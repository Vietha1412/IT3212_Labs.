﻿using System;
using System.Collections.Generic;
using System.Linq;
using Lab06_ThreeLayerMemory.DAL;

namespace Lab06_ThreeLayerMemory.BUS
{
    public class SinhVienBUS
    {
        private readonly SinhVienDAL _dal = new SinhVienDAL();

        public List<SinhVien> GetAll() => _dal.GetAll();

        public void Add(SinhVien sv)
        {
            if (string.IsNullOrWhiteSpace(sv.MaSV))
                throw new ArgumentException("Mã sinh viên không được để trống.");
            if (string.IsNullOrWhiteSpace(sv.HoTen))
                throw new ArgumentException("Họ tên không được để trống.");
            if (_dal.GetAll().Any(x => x.MaSV == sv.MaSV))
                throw new InvalidOperationException("Mã sinh viên đã tồn tại.");

            _dal.Add(sv);
        }

        public void Delete(string maSV)
        {
            if (string.IsNullOrWhiteSpace(maSV))
                throw new ArgumentException("Vui lòng chọn sinh viên cần xóa.");
            _dal.Delete(maSV);
        }

        public Dictionary<string, List<SinhVien>> GetGroupedByKhoa()
        {
            var list = _dal.GetAll();
            return list.GroupBy(x => x.Khoa)
                       .ToDictionary(g => g.Key, g => g.ToList());
        }
        public void ExportToCsv()
        {
            _dal.SaveToCsv();
        }

        public void ImportFromCsv()
        {
            _dal.LoadFromCsv();
        }
    }
}