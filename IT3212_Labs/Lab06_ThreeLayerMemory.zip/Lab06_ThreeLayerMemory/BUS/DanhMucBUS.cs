﻿using System.Collections.Generic;
using Lab06_ThreeLayerMemory.DAL;

namespace Lab06_ThreeLayerMemory.BUS
{
    public class DanhMucBUS
    {
        private readonly DanhMucDAL _dal = new DanhMucDAL();

        public Dictionary<string, List<string>> GetAll() => _dal.GetAll();

        public void SaveData(Dictionary<string, List<string>> data)
        {
            _dal.SaveChanges(data);
        }
    }
}