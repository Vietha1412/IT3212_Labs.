﻿using System;
using System.Collections.Generic;
using System.Linq;
using Lab06_ThreeLayerMemory.DAL;

namespace Lab06_ThreeLayerMemory.BUS
{
    public class SanPhamBUS
    {
        private readonly SanPhamDAL _dal = new SanPhamDAL();

        public List<SanPham> GetAll() => _dal.GetAll();

        public void Add(SanPham sp)
        {
            if (string.IsNullOrWhiteSpace(sp.MaSP))
                throw new ArgumentException("Mã sản phẩm không được để trống.");
            if (_dal.GetAll().Any(x => x.MaSP == sp.MaSP))
                throw new InvalidOperationException("Mã sản phẩm đã tồn tại.");
            _dal.Add(sp);
        }

        public void Update(SanPham sp)
        {
            if (string.IsNullOrWhiteSpace(sp.MaSP))
                throw new ArgumentException("Vui lòng chọn sản phẩm cần sửa.");
            _dal.Update(sp);
        }

        public void Delete(string maSP)
        {
            if (string.IsNullOrWhiteSpace(maSP))
                throw new ArgumentException("Vui lòng chọn sản phẩm cần xóa.");
            _dal.Delete(maSP);
        }

        public List<SanPham> Search(string keyword)
        {
            var list = _dal.GetAll();
            if (string.IsNullOrWhiteSpace(keyword)) return list;
            return list.Where(x => x.MaSP.ToLower().Contains(keyword.ToLower()) ||
                                   x.TenSP.ToLower().Contains(keyword.ToLower())).ToList();
        }

        public List<SanPham> SortByPriceAscending()
        {
            return _dal.GetAll().OrderBy(x => x.DonGia).ToList();
        }

        public double CalculateTotalInventoryValue()
        {
            return _dal.GetAll().Sum(x => x.ThanhTien);
        }
    }
}