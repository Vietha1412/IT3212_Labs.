﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab07_ADONET_Connection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            try
            {
                // Ghi nhận thời điểm bắt đầu kết nối
                DateTime startTime = DateTime.Now;

                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();

                    // Tổng hợp thông tin trạng thái theo yêu cầu Bài 9
                    string statusInfo = "--- THÔNG TIN TRẠNG THÁI KẾT NỐI ---\n\n" +
                                        $"• Data Source: {conn.DataSource}\n" +
                                        $"• Database: {conn.Database}\n" +
                                        $"• Server Version: {conn.ServerVersion}\n" +
                                        $"• Connection State: {conn.State}\n" +
                                        $"• Thời gian kết nối: {startTime:dd/MM/yyyy HH:mm:ss}";

                    MessageBox.Show(statusInfo, "Trạng thái kết nối", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Lỗi kết nối: " + ex.Message,
                                "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}