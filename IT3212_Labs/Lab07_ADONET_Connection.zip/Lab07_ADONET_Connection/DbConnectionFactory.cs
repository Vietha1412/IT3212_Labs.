﻿using System.Configuration;
using System.Data.SqlClient;

namespace Lab07_ADONET_Connection
{
    public static class DbConnectionFactory
    {
        // Đọc chuỗi kết nối động từ App.config thông qua tên "QLSinhVienConn"
        private static readonly string ConnectionString =
            ConfigurationManager.ConnectionStrings["QLSinhVienConn"].ConnectionString;

        public static SqlConnection Create()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}